
from analizadorseguro.decoradores import *
from datosx import models

from django.shortcuts import render, redirect
from django.core.exceptions import ObjectDoesNotExist
from django.http import HttpResponse, JsonResponse
import datetime
import analizadorseguro.settings as conf
from datetime import timezone
import time
import crypt
import requests
import random


def sanitizar_campos(campos):
    """
    Rutina encargada de sanitizar campos de entrada entrantes

    Keywords:
    campos: [str] que incluyen las variables a analizar para sanitizar
    """
    band = 0
    for campo in campos:
        lista = []
        lista.append(campo)
        if campo.find('=') != -1:
            band = 1
        elif campo.find(';') != -1:
            band = 1
        elif campo.find("\r") != -1:
            band = 1
        elif campo.find("-") != -1:
            band = 1
        elif campo.find("*") != -1:
            band = 1
        elif lista != campo.split("'"):
            band = 1
        elif lista != campo.split('"'):
            band = 1
    if band == 0:
        return True
    else:
        return False

def obtener_ip_cliente(request):
    """
    Rutina encargada de extraer la dirección lógica de clientes

    Keyword Arguments:
    request --
    returns: HTTP_Response
    """
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip

def es_ip_conocida(ip: str):
    """
    Determina si la ip ya está en la base de datos

    Keyword Arguments:
    ip: str
    returns: bool
    """
    registros = models.Peticion.objects.filter(ip=ip)
    return len(registros) != 0


def esta_tiempo_en_ventana(timestamp: datetime):
    """
    Rutina que verifica si las peticiones estan en tiempo de ventana

    Keyword
    timestamp: datetime tiempo pasado desde el ultimo intento
    """
    momento_actual = datetime.datetime.now(timezone.utc)
    resta = momento_actual - timestamp
    if resta.seconds < conf.VENTANA_SEGUNDOS_INTENTOS_PETICION:
        print(resta)
        return True
    return False

def guardar_peticion(ip: str, intentos: int):
    """
    Rutina para almacenar información de peticion, considerando las reglas de bloqueo de peticiones.

    Keyword:
    ip: str Recibe la ip del cliente que desea conectarse
    intentos: int es el valor a guardar de intentos
    """
    fecha_actual = datetime.datetime.now()
    if not es_ip_conocida(ip):
        entrada = models.Peticion(ip=ip, intentos=1, timestamp=fecha_actual)
        entrada.save()
        return
    registro = models.Peticion.objects.get(ip=ip)
    registro.intentos = intentos
    registro.timestamp = fecha_actual
    registro.save()

def puede_hacer_peticion(ip: str):
    """
    Verdadero si la IP no ha alcanzado el limite de intentos

    Keyword:
    ip: str Recibe la ip del cliente que desea conectarse
    returns:Bool
    """
    if not es_ip_conocida(ip):
        guardar_peticion(ip, 1)
        print("nueva ip")
        return True
    registro = models.Peticion.objects.get(ip=ip)
    if not esta_tiempo_en_ventana(registro.timestamp):
        guardar_peticion(ip, 1)
        print("Nunca cae en vantana")
        return True
    else:
        if (registro.intentos + 1) > conf.INTENTOS_MAXIMOS_PETICION:
            guardar_peticion(ip, registro.intentos + 1)
            return False
        else:
            guardar_peticion(ip, registro.intentos + 1)
            return True




def es_contrasena_valida(contrasena, contrasena_hasheada):
    """
    Esta rutina valida que la contraseña ingresada coincida con la registrada en la base de datos
    """
    partes=contrasena_hasheada.split('$')
    complemento='$'+partes[1]+'$'+partes[2]
    return contrasena_hasheada == crypt.crypt(contrasena, complemento)

def envio_autenticacion_telegram(token_bot: str, chat_id: str):
    """
    Rutina que realiza el envío de código de verificación a Telegram para la autenticación de doble factor

    Keywords:
    token_bot: str
    chat_id: str
    """
    token = random.randrange(10000, 99999)
    mensaje = "Tu código de verificación es: " + str(token)
    send_text = 'https://api.telegram.org/bot' + token_bot + '/sendMessage?chat_id=' + chat_id + '&parse_mode=Markdown&text=' + mensaje
    requests.get(send_text)
    return token



def gestion_token_autenticacion(token: int, usuario_id):
    """
    Esta función gestiona el almacenamiento del troken en la base de datos
    """
    fecha_actual = datetime.datetime.now()
    try:
        usuario_sesion = models.Telegramtokensx.objects.get(idusuarioauth=usuario_id)
        models.Telegramtokensx(pk=usuario_sesion.pk, idusuarioauth=usuario_id, token=token, timestamp=fecha_actual).save()
    except ObjectDoesNotExist:
        models.Telegramtokensx(idusuarioauth=usuario_id, token=token, timestamp=fecha_actual).save()


def esta_tiempo_en_ventana_token(usuario, codigo):
    timestamp = models.Telegramtokensx.objects.get(idusuarioauth=usuario)
    momento_actual = datetime.datetime.now(timezone.utc)
    resta = momento_actual - timestamp.timestamp
    if resta.seconds < conf.VENTANA_SEGUNDOS_TOKEN:
        print(resta)
        return True
    return False

def limpiar_token(usuario):
    usuario_token = models.Telegramtokensx.objects.get(idusuarioauth=usuario)
    models.Telegramtokensx(pk=usuario_token.pk, idusuarioauth=usuario, token="", timestamp=usuario_token.timestamp).save()

def aplica_politicas_contrasena(password):
    minimo_caracteres = 10
    maximo_caracteres = 35
    flag = 0
    #fallidos = []

    # check more than min_length
    if len(password) < minimo_caracteres or len(password) > maximo_caracteres:
        flag=1

    # check less than max_length
    if len(password) > maximo_caracteres:
        flag=1

    # check for digit
    if not any(char.isdigit() for char in password):
        flag=1

    # check for letter
    if not any(char.isalpha() for char in password):
        flag=1

    # check for Upper
    if not any(char.isupper() for char in password):
        flag=1

    # check for Lower
    if not any(char.islower() for char in password):
        flag=1

    #check for special character
    special_characters = "!@#$%^&|*()-+?_=,<>/"
    if not any(c in special_characters for c in password):
        flag=1

    if flag!=0:
        return False
    else:
        return True


def asignar_bot():
    bot_asignado = []
    botsDisponibles = {'bot1' : '5366447996:AAEDTucG1bRHp9o0aiXT0Ij_NYMSTUYr1R8',
                       'bot2' : '5314775826:AAFTWyEyE4lNx0w__lzqCal_-wubcqjjcQg',
                       'bot3' : '5331881180:AAFNvDw00KeDXbqDNrMFePLDcB4T3fKsRtg',
                       'bot4' : '5384369991:AAE2IeGv5ozB78Ka2rhtXIu-H543hwJibs0',
                       'bot5' : '5305925243:AAHlSn9jqwc74L_qpqdu7MC_RDmUvLOkg6I',}

    botsNombres = {'bot1' : '@AutenticacionDoobleFactor_bot',
                   'bot2' : '@AutenticacionDoobleFactor2_bot',
                   'bot3' : '@AutenticacionDoobleFactor3_bot',
                   'bot4' : '@AutenticacionDoobleFactor4_bot',
                   'bot5' : '@AutenticacionDoobleFactor5_bot',}

    numeral=random.randrange(1, 6)
    asignado='bot'+str(numeral)

    bot_asignado.append(botsNombres[asignado])
    bot_asignado.append(botsDisponibles[asignado])
    bot_asignado.append(asignado)
    print("Te tocó el bot "+asignado+" con Nombre "+botsNombres[asignado]+" Mandale el mensaje /start antes de intentar la auteticación de doble factor")
    return bot_asignado





@no_logueado
def inicio_sesion(request):
    """
    Esta rutina se encarga de autenticar a los usuarios que intentan acceder al sistema

    Keyword Arguments:
    request --
    returns: HTTP_Response
    """
    displayx = "none"
    errores = []
    if request.method == 'GET':
        return render(request, 'inicio_sesion.html', {'display': displayx})
    elif request.method == 'POST':
        if puede_hacer_peticion(obtener_ip_cliente(request)):
            campos = []
            usuario = request.POST.get('usuario','')
            contrasena = request.POST.get('contrasena','')
            if usuario and contrasena:
                campos.append(usuario)
                campos.append(contrasena)
                if sanitizar_campos(campos):
                    try:
                        usuario_basedatos = models.Usuarios.objects.get(identificador=usuario)
                        if es_contrasena_valida(contrasena, usuario_basedatos.contrasenaHasheada):
                            request.session['usuario_sesion'] = request.POST.get('usuario', '')
                            usuario_basedatos = models.Usuarios.objects.get(identificador=usuario)
                            token = envio_autenticacion_telegram(usuario_basedatos.tokenBotAsociado, usuario_basedatos.telegramPersonalID)
                            gestion_token_autenticacion(token, usuario_basedatos.pk)
                            return redirect('/auth_doble_factor/')
                        else:
                            displayx = "block"
                            errores.append('Usuario o contraseña invalidos')
                    except:
                        displayx = "block"
                        errores.append('valioUsuario o contraseña invalidos')
                else:
                    displayx = "block"
                    errores.append('No se pasaron las variables adecuadas')
            else:
                displayx = "block"
                errores.append('No se pasaron las variables adecuadas')

        else:
            displayx = "block"
            errores.append('Numero de intentos excedido')
        return render(request, 'inicio_sesion.html', {'errores': errores, 'display': displayx})


@logueado
def home(request):
    return render(request, 'home.html')

@no_logueado
def auth_doble_factor(request):
    """
    Esta rutina realiza la verificación de doble factor durante el inicio de sisón

    Keyword Arguments:
    request --
    returns: HTTP_Response
    """
    if request.method == 'GET':
        return render(request, 'doble_factor.html')
    elif request.method == 'POST':
        codigo = request.POST.get('codigo','')
        usuario = request.session.get('usuario_sesion', '')
        if esta_tiempo_en_ventana_token(usuario, codigo):
            print(usuario)
            codigo_base = models.Telegramtokensx.objects.get(idusuarioauth=usuario)
            if codigo_base.token == codigo:
                limpiar_token(usuario)
                #cambio a variable
                cookiesesion = request.session['logueado'] = True
                #respuesta = render(request, 'home.html')
                respuesta = redirect('/home/')
                respuesta.set_cookie('sesionstat', cookiesesion, max_age=None, httponly=True)
                return respuesta
                #return redirect('/home/')
            else:
                limpiar_token(usuario)
                return redirect('/logout/')
        else:
            limpiar_token(usuario)
            return redirect('/logout/')


def cifrar_password(password: str):
    return crypt.crypt(password,'$6$' + "hola")

@no_logueado
def registro(request):
    """
    Esta rutina se encarga de registrar usuarios en el sistema

    Keyword Arguments:
    request --
    returns: HTTP_Response
    """
    displayx = "none"
    errores = []
    #resultado = []
    if request.method == 'GET':
        return render(request, 'registro.html', {'display': displayx})
    elif request.method == 'POST':
        if puede_hacer_peticion(obtener_ip_cliente(request)):
            campos = []
            nombre = request.POST.get('nombre','')
            identificador = request.POST.get('identificador','')
            telegram_id = request.POST.get('telegram_id','')
            password = request.POST.get('password','')
            conf_password = request.POST.get('conf_password','')
            tipo_cuenta = request.POST.get('cuenta','')
            if nombre and password and identificador and telegram_id and conf_password:
                campos.append(nombre)
                campos.append(identificador)
                campos.append(telegram_id)
                campos.append(password)
                campos.append(conf_password)
                if sanitizar_campos(campos):
                    if password == conf_password:
                        if aplica_politicas_contrasena(password):
                            password_cifrada = cifrar_password(password)
                            bot_asigando = asignar_bot()
                            models.Usuarios(identificador=identificador, nombre=nombre, contrasenaHasheada=password_cifrada, tokenBotAsociado=bot_asigando[1], telegramPersonalID=telegram_id, tipoUsuario=tipo_cuenta).save()
                            displayx = "block"
                            errores.append("Te tocó el "+bot_asigando[2]+" con Nombre "+bot_asigando[0]+" envíale /start antes de intentar la auteticación de doble factor")
                            return render(request, 'registro.html', {'errores': errores, 'display': displayx})
                        else:
                            displayx = "block"
                            errores.append('La contraseña no cumple las políticas de seguridad adecuadas')
                    else:
                        displayx = "block"
                        errores.append('Las contraseñas no coinciden')
                else:
                    displayx = "block"
                    errores.append('No se pasaron las variables adecuadas')
            else:
                displayx = "block"
                errores.append('No se pasaron las variables adecuadas')
        else:
            displayx = "block"
            errores.append('Numero de intentos excedido')
        return render(request, 'registro.html', {'errores': errores, 'display': displayx})




@logueado
def logout(request):
    """
    Esta rutina finaliza la sesión delñ usuario

    Keyword Arguments:
    request --
    returns: HTTP_Response
    """
    #request.session['logueado'] = False
    #request.session['sesionstat'] = False
    request.session.flush()
    #request.session['sesionstat'] = False
    return redirect('/inicio_sesion/')

