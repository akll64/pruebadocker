from django.shortcuts import redirect

def logueado(vista):
    def interna(request, *args, **kwargs):
        logueado = request.session.get('logueado', False)
        if not logueado:
            return redirect('/inicio_sesion/')
        else:
            return vista(request, *args, **kwargs)
    return interna

def no_logueado(vista):
    def interna(request, *args, **kwargs):
        logueado = request.session.get('logueado', False)
        if logueado:
            return redirect('/home/')
        else:
            return vista(request, *args, **kwargs)
    return interna