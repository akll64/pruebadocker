import subprocess


entrada="$1"
esperada ="$2"


archivo= [ar for ar in os.listdir('.') if ar.endswith('sh')]

comando = =["./"+lista[0], entrada]

salida = subprocess.Popen(comando, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

stdout, stderr = salida.communicate()

#print(stdout.decode('utf-8').strip())

if esperada == stdout.decode('utf-8').strip():
        print("Ejercicio completado")
else:
	print("Error, salida inesperada")
