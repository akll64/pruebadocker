from django.db import models

# Create your models here.

class Peticion(models.Model):
   ip = models.GenericIPAddressField(unique=True)
   intentos = models.IntegerField(default=1)
   timestamp = models.DateTimeField()


class Estudiantes(models.Model):
    nombre = models.CharField(max_length=55)
    matricula = models.CharField(max_length=9,unique=True,primary_key=True) #Formato de la UV 1:S 2:Año 6:NúmerosID
    contrasenaHasheada = models.CharField(max_length=110) #106 son los caracteres que salen después de hasheado
    tokenBotAsociado = models.CharField(max_length=48)
    telegramPersonalID= models.CharField(max_length=15) #puede variar con el tiempo, AL TERMINAR PRUEBAS USAREMOS EL UNIQUE

class Profesores(models.Model):
    nombre = models.CharField(max_length=55)
    numeroPersonal = models.CharField(max_length=10,unique=True,primary_key=True) #Formato inventado de la UV 1:X 9:NúmerosID
    contrasenaHasheada = models.CharField(max_length=110) #106 son los caracteres que salen después de hasheado
    tokenBotAsociado = models.CharField(max_length=48)
    telegramPersonalID= models.CharField(max_length=15) #puede variar con el tiempo


#Final de usuarios

class Usuarios(models.Model):
    identificador = models.CharField(max_length=9,unique=True,primary_key=True) #Formato de la UV 1:S 2:Año 6:NúmerosID
    nombre = models.CharField(max_length=55)
    contrasenaHasheada = models.CharField(max_length=110) #106 son los caracteres que salen después de hasheado
    tokenBotAsociado = models.CharField(max_length=48)
    telegramPersonalID= models.CharField(max_length=15) #puede variar con el tiempo, AL TERMINAR PRUEBAS USAREMOS EL UNIQUE
    tipoUsuario = models.CharField(max_length=1) #0 maestro, 1 alumno


class Telegramtokensx(models.Model):
    idusuarioauth = models.CharField(max_length=9)
    token = models.CharField(max_length=5)
    timestamp = models.DateTimeField()
