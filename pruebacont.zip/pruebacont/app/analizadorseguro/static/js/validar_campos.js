$(function(){

    function es_campo_vacio(campo) {
        let contenido = campo.value.trim();
        console.log(contenido == "")
        return contenido == "";
    }


    function listar_errores_formulario() {
        let resultado = [];
        if(es_campo_vacio($("#usuario").get(0))) {
            resultado.push("El campo de usuario está vacío" + "<br>");
        }
        if(es_campo_vacio($("#password").get(0))) {
            resultado.push("El campo password está vacía" + "<br>");
        }
        return resultado;
    }

    function desplegar_errores(lista_errores) {
        if(lista_errores.length == 0) {
            return;
        }
        $("#lista_errores").html("");
        console.log("le:  "+ lista_errores)
        for(let i = 0; i < lista_errores.length; i++) {
            $("#lista_errores").html(lista_errores);
        }

        $("#divErrores").fadeIn("5000");
    }

    $("#formulario").on("submit", function(event)
    {
        let lista_errores = listar_errores_formulario();
        if(lista_errores.length > 0) {
            desplegar_errores(lista_errores);
            event.preventDefault();
            $("#divErrores").css("display","block");

        }

    });

});