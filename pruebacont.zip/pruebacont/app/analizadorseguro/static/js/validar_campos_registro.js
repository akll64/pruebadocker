$(function(){

    var pwd = document.getElementById("password");
    pwd.addEventListener('keyup', function() {
        var password = pwd.value

        if (pwd.length === 0) {
            document.getElementById("progress").value = "0";
            return;
        }
        var prog = [/[!@#$%&|*()+_=,<>]/, /[A-Z]/, /[0-9]/, /[a-z]/]
            .reduce((memo, test) => memo + test.test(password), 0);

        // Length must be at least 10 chars
        if (prog > 2 && password.length > 9) {
            prog++;
        }

        var progress = "";
        switch (prog) {
            case 0:
            case 1:
            case 2:
                progress = "25";
                break;
            case 3:
                progress = "50";
                break;
            case 4:
                progress = "75";
                break;
            case 5:
                progress = "100";

                break;
        }
        document.getElementById("progress").value = progress;
    });


    function es_campo_vacio(campo) {
        let contenido = campo.value.trim();
        console.log(contenido == "")
        return contenido == "";
    }
    function es_passwords_iguales() {
        return $("#password").val() == $("#conf_password").val();
    }


    function listar_errores_formulario() {
        let resultado = [];
        if(es_campo_vacio($("#nombre").get(0))) {
            resultado.push("El campo de nombre está vacío" + "<br>");
        }
        if(es_campo_vacio($("#identificador").get(0))) {
            resultado.push("El campo de identificador está vacío" + "<br>");
        }
        if(es_campo_vacio($("#telegram_id").get(0))) {
            resultado.push("El campo de id telegram está vacío" + "<br>");
        }
        if(es_campo_vacio($("#password").get(0))) {
            resultado.push("El campo password está vacía" + "<br>");
        }
        if(es_campo_vacio($("#conf_password").get(0))) {
            resultado.push("El campo confirmación de password está vacía" + "<br>");
        }
        if(!es_passwords_iguales()) {
            resultado.push("Los passwords no coinciden");
        }
        return resultado;
    }

    function desplegar_errores(lista_errores) {
        if(lista_errores.length == 0) {
            return;
        }
        $("#lista_errores").html("");
        console.log("le:  "+ lista_errores)
        for(let i = 0; i < lista_errores.length; i++) {
            $("#lista_errores").html(lista_errores);
        }

        $("#divErrores").fadeIn("5000");
    }

    $("#formulario").on("submit", function(event)
    {
        let lista_errores = listar_errores_formulario();
        if(lista_errores.length > 0) {
            desplegar_errores(lista_errores);
            event.preventDefault();
            $("#divErrores").css("display","block");

        }

    });

});